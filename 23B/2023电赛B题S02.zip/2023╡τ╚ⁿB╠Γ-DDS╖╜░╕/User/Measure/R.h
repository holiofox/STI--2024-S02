#ifndef __R_H
#define	__R_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
float getR(); // ��λ��

float getBaseR(float l);

void calVTask();

void calRTask();

#endif /* __R_H */